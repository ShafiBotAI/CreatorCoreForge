# API Setup

1. Obtain an OpenAI API key and add it to the `OPENAI_API_KEY` environment variable.
2. Configure Firebase for cloud storage and add `GoogleService-Info.plist`.
3. Provide ElevenLabs credentials if voice features are enabled.
