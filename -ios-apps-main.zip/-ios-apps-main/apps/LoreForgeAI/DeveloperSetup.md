# Developer Setup

- Install the latest Xcode and Node.js for the desktop builds
- Run `pod install` if Cocoapods dependencies are added
- Open `LoreForgeAIFull/LoreForgeAI.xcodeproj` and build
- Ensure `OPENAI_API_KEY` is exported for command-line testing
