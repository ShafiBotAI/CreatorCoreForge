import SwiftUI

@main
struct InkwellAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
