# Developer Setup

- Install Xcode 15 and Swift 5.7
- Run `swift package resolve` in `TradeMindAIFull`
- Open `TradeMindAIFull` in Xcode and build
- Set `OPENAI_API_KEY` before running integration tests
