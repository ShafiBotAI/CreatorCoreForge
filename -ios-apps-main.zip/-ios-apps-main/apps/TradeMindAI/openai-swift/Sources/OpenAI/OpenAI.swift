public struct OpenAIClient {
    public init(apiKey: String) {}
}
