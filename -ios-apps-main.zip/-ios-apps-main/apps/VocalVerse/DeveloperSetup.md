# Developer Setup

- Install Xcode and open `VocalVerseFull/VocalVerse.xcodeproj`
- Run `swift package resolve` to fetch dependencies
- Provide `OPENAI_API_KEY` and `ELEVEN_API_KEY` in your scheme
