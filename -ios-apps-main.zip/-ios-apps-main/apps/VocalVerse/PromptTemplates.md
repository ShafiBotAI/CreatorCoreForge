# Prompt Templates

The following prompts help generate audio narration and metadata.

```json
{
  "chapterSegmentation": "Split this chapter into narration-ready segments: {{chapter}}",
  "narration": "Provide a dramatic reading of: {{text}}"
}
```
