# API Setup

1. Add your OpenAI API key under `OPENAI_API_KEY` in Xcode.
2. Download `GoogleService-Info.plist` for Firebase authentication and storage.
3. Provide ElevenLabs credentials for voice rendering under `ELEVEN_API_KEY`.
